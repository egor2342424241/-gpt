# Glass UI — стеклянный интерфейс на Jetpack Compose + AGSL

Преломление, хроматическая дисперсия, размытие, френель и блики по кромке.

## Сборка
1. Открой папку `GlassApp` в Android Studio (Ladybug или новее), дождись Gradle Sync.
2. Запусти на устройстве/эмуляторе с Android 13+ (API 33) — там работает шейдер.
   На Android 8–12 включается упрощённый фолбэк (полупрозрачное стекло без преломления).
3. APK: `Build > Build Bundle(s) / APK(s) > Build APK(s)` или `./gradlew assembleDebug`
   (файл появится в `app/build/outputs/apk/debug/`).

Если Studio предложит обновить версии AGP/Kotlin/Compose BOM — соглашайся, код от этого не зависит.

## Как устроено
- `GlassShaders.kt` — AGSL: фон как функция `background(coord, time)` и стеклянный шейдер.
  Стекло не копирует пиксели под собой, а пересчитывает ту же функцию фона в смещённых
  координатах (по нормали SDF скруглённого прямоугольника) — отсюда честная линза.
- `AgslDrawers.kt` — обёртки над `RuntimeShader`.
- `GlassScene.kt` — `GlassSurface` (стеклянная панель), `AnimatedBackground`, фолбэк.
- `Components.kt` — кнопка, нижняя навигация со скользящим стеклом, слайдеры.
- `MainActivity.kt` — демо-экран. Слайдеры меняют параметры стекла вживую.

## Параметры
`GlassSurface(cornerRadius, bevel, refractionScale)` + глобальные `refraction`, `dispersion`, `blur`
в `GlassScene`. Если тормозит на слабом телефоне — уменьши число отсчётов (`6`) в `glassSample`.

## Ограничения
Стекло преломляет только анимированный фон (шейдер), а не произвольные элементы под ним.
Для преломления реального Compose-контента нужен захват слоя (`RenderEffect` + `graphicsLayer`).
