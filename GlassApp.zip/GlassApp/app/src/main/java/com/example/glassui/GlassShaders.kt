package com.example.glassui

/**
 * AGSL-шейдеры (Android 13+, API 33).
 *
 * Идея: фон — аналитическая функция background(координата, время). Стеклянная панель
 * не "снимает" картинку под собой, а пересчитывает ту же функцию в смещённых
 * (преломлённых) координатах. Поэтому преломление честное, без захвата экрана.
 */
internal object GlassShaders {

    private const val COMMON = """
uniform float2 resolution;   // размер фона в пикселях
uniform float time;          // секунды

float3 background(float2 fc, float t) {
    float2 uv = fc / resolution;
    float aspect = resolution.x / resolution.y;
    float2 p = (uv - 0.5) * float2(aspect, 1.0);

    float3 col = mix(float3(0.04, 0.06, 0.20), float3(0.16, 0.04, 0.24), float3(uv.y));

    // плавающие цветные пятна
    for (int i = 0; i < 5; i++) {
        float fi = float(i);
        float2 c = float2(sin(t * 0.23 + fi * 1.9) * 0.42 * aspect,
                          cos(t * 0.19 + fi * 2.7) * 0.42);
        float d = length(p - c);
        float3 hue = 0.55 + 0.45 * cos(6.28318 * (fi * 0.21 + float3(0.0, 0.33, 0.67)) + t * 0.05);
        col += hue * 0.55 * exp(-d * d * 10.0);
    }

    // тонкая сетка: по ней хорошо видно искажение линзы
    float2 gp = abs(fract(p * 9.0) - 0.5);
    float gridLine = smoothstep(0.46, 0.5, max(gp.x, gp.y));
    col += float3(0.06) * gridLine;

    return float3(1.0) - exp(-col * 1.6);
}
"""

    const val BACKGROUND = COMMON + """
half4 main(float2 fc) {
    return half4(half3(background(fc, time)), 1.0);
}
"""

    const val GLASS = COMMON + """
uniform float2 origin;       // левый верхний угол панели в координатах фона
uniform float2 size;         // размер панели
uniform float radius;        // радиус скругления
uniform float refraction;    // сила преломления, px
uniform float dispersion;    // хроматическая дисперсия, 0..~0.3
uniform float blur;          // радиус размытия, px
uniform float bevel;         // ширина "скошенной" кромки, px

float sdRoundBox(float2 p, float2 hs, float r) {
    float2 q = abs(p) - hs + float2(r);
    return min(max(q.x, q.y), 0.0) + length(max(q, float2(0.0))) - r;
}

// фон за стеклом: 6 отсчётов на канал (размытие) + разное смещение по R/G/B (дисперсия)
float3 glassSample(float2 pos, float2 disp) {
    float2 dR = disp * (1.0 + dispersion);
    float2 dG = disp;
    float2 dB = disp * (1.0 - dispersion);
    float sr = 0.0;
    float sg = 0.0;
    float sb = 0.0;
    for (int i = 0; i < 6; i++) {
        float a = float(i) * 2.39996;
        float rad = blur * sqrt((float(i) + 0.5) / 6.0);
        float2 o = float2(cos(a), sin(a)) * rad;
        sr += background(pos - dR + o, time).r;
        sg += background(pos - dG + o, time).g;
        sb += background(pos - dB + o, time).b;
    }
    return float3(sr, sg, sb) / 6.0;
}

half4 main(float2 fc) {
    float2 hs = size * 0.5;
    float2 p = fc - hs;
    float d = sdRoundBox(p, hs, radius);          // < 0 внутри панели

    // нормаль к кромке из градиента SDF
    float2 g = float2(
        sdRoundBox(p + float2(1.0, 0.0), hs, radius) - sdRoundBox(p - float2(1.0, 0.0), hs, radius),
        sdRoundBox(p + float2(0.0, 1.0), hs, radius) - sdRoundBox(p - float2(0.0, 1.0), hs, radius));
    float2 n = g / max(length(g), 0.0001);

    float bv = max(min(bevel, min(hs.x, hs.y)), 1.0);
    float depth = clamp(-d / bv, 0.0, 1.0);       // 0 у кромки, 1 в глубине
    float edge = pow(1.0 - depth, 2.5);           // линза гнёт свет у краёв, в центре плоско

    float2 disp = n * edge * refraction;
    float3 col = glassSample(fc + origin, disp);

    // лёгкая молочная тонировка
    col = mix(col, float3(1.0), float3(0.09));

    // френель по кромке
    float fres = pow(1.0 - depth, 4.0);
    col += float3(fres * 0.25);

    // блики: основной сверху-слева, слабый отражённый снизу-справа
    float2 L = normalize(float2(-0.6, -0.8));
    float facing = dot(n, L);
    float rimMask = 1.0 - smoothstep(0.0, 0.55, depth);
    float spec = pow(max(facing, 0.0), 5.0) + 0.5 * pow(max(-facing, 0.0), 5.0);
    col += float3(spec * rimMask * 0.55);

    // тонкая светлая окантовка
    float border = 1.0 - smoothstep(0.0, 1.5, abs(d + 0.75));
    col += float3(border * (0.25 + 0.55 * max(facing, 0.0)));

    // мягкий блик сверху
    col += float3(0.06 * (1.0 - fc.y / size.y));

    return half4(half3(clamp(col, float3(0.0), float3(1.0))), 1.0);
}
"""
}
