package com.example.glassui

import android.graphics.RuntimeShader
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.drawscope.DrawScope

/** Интерфейсы нужны, чтобы код для API < 33 не трогал класс RuntimeShader. */
internal interface BackgroundDrawer {
    fun draw(scope: DrawScope, time: Float)
}

internal interface GlassDrawer {
    fun draw(
        scope: DrawScope,
        time: Float,
        screen: Size,
        origin: Offset,
        cornerRadius: Float,
        refraction: Float,
        dispersion: Float,
        blur: Float,
        bevel: Float,
    )
}

@RequiresApi(Build.VERSION_CODES.TIRAMISU)
internal class AgslBackground : BackgroundDrawer {
    private val shader = RuntimeShader(GlassShaders.BACKGROUND)
    private val brush = ShaderBrush(shader)

    override fun draw(scope: DrawScope, time: Float) {
        shader.setFloatUniform("resolution", scope.size.width, scope.size.height)
        shader.setFloatUniform("time", time)
        scope.drawRect(brush)
    }
}

@RequiresApi(Build.VERSION_CODES.TIRAMISU)
internal class AgslGlass : GlassDrawer {
    private val shader = RuntimeShader(GlassShaders.GLASS)
    private val brush = ShaderBrush(shader)

    override fun draw(
        scope: DrawScope,
        time: Float,
        screen: Size,
        origin: Offset,
        cornerRadius: Float,
        refraction: Float,
        dispersion: Float,
        blur: Float,
        bevel: Float,
    ) {
        shader.setFloatUniform("resolution", screen.width, screen.height)
        shader.setFloatUniform("time", time)
        shader.setFloatUniform("origin", origin.x, origin.y)
        shader.setFloatUniform("size", scope.size.width, scope.size.height)
        shader.setFloatUniform("radius", cornerRadius)
        shader.setFloatUniform("refraction", refraction)
        shader.setFloatUniform("dispersion", dispersion)
        shader.setFloatUniform("blur", blur)
        shader.setFloatUniform("bevel", bevel)
        scope.drawRoundRect(brush = brush, cornerRadius = CornerRadius(cornerRadius))
    }
}
