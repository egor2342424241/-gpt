package com.example.glassui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.withFrameNanos
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { GlassApp() }
    }
}

@Composable
fun GlassApp() {
    val scene = remember { GlassScene() }

    // один таймер на всё приложение
    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        while (true) {
            withFrameNanos { scene.time.floatValue = (it - start) / 1_000_000_000f }
        }
    }

    CompositionLocalProvider(LocalGlassScene provides scene) {
        Box(Modifier.fillMaxSize()) {
            AnimatedBackground(Modifier.fillMaxSize())
            DemoScreen()
        }
    }
}

@Composable
fun DemoScreen() {
    val scene = LocalGlassScene.current
    var tab by remember { mutableIntStateOf(0) }

    Box(Modifier.fillMaxSize()) {
        // шар-линза под панелями: его можно таскать пальцем
        DraggableOrb(Modifier.align(Alignment.BottomCenter).padding(bottom = 130.dp))

        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.systemBars)
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Spacer(Modifier.height(8.dp))
            Text("Glass UI", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            Text(
                "Преломление, дисперсия и блики на AGSL",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 15.sp,
            )

            GlassSurface(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Жидкое стекло", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        "Панель преломляет живой фон: у краёв изображение изгибается, а цвета слегка расходятся.",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 14.sp,
                    )
                }
            }

            GlassSurface(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) {
                    LabeledSlider("Преломление", scene.refraction.floatValue, 0f..48f, "%.0f dp") {
                        scene.refraction.floatValue = it
                    }
                    LabeledSlider("Дисперсия", scene.dispersion.floatValue, 0f..0.3f) {
                        scene.dispersion.floatValue = it
                    }
                    LabeledSlider("Размытие", scene.blur.floatValue, 0f..16f, "%.0f dp") {
                        scene.blur.floatValue = it
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                listOf("Играть", "Нравится", "Ещё").forEach { label ->
                    GlassButton(label, Modifier.weight(1f)) { }
                }
            }

            Spacer(Modifier.weight(1f))
            GlassNavBar(selected = tab, onSelect = { tab = it })
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
fun DraggableOrb(modifier: Modifier = Modifier) {
    var offset by remember { mutableStateOf(Offset.Zero) }
    GlassSurface(
        modifier = modifier
            .offset { IntOffset(offset.x.roundToInt(), offset.y.roundToInt()) }
            .size(130.dp)
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    offset += dragAmount
                }
            },
        cornerRadius = 65.dp,
        bevel = 55.dp,
        refractionScale = 2.2f,
    ) {}
}
