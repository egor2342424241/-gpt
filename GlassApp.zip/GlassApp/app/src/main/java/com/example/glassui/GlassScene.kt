package com.example.glassui

import android.os.Build
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

/** Общее состояние сцены. Читается только внутри draw-блоков, поэтому анимация не вызывает рекомпозицию. */
@Stable
class GlassScene {
    val time = mutableFloatStateOf(0f)
    var screenSize by mutableStateOf(Size.Zero)

    // настройки стекла (читаются шейдером каждый кадр)
    val refraction = mutableFloatStateOf(26f)   // dp
    val dispersion = mutableFloatStateOf(0.10f)
    val blur = mutableFloatStateOf(5f)          // dp
}

val LocalGlassScene = compositionLocalOf<GlassScene> { error("GlassScene не предоставлена") }

private val sdkHasAgsl: Boolean get() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU

/** Анимированный фон. На Android 13+ рисуется тем же шейдером, что и "видит" стекло. */
@Composable
fun AnimatedBackground(modifier: Modifier = Modifier) {
    val scene = LocalGlassScene.current
    val drawer: BackgroundDrawer? = remember {
        if (sdkHasAgsl) AgslBackground() else null
    }
    Box(
        modifier
            .onSizeChanged { scene.screenSize = Size(it.width.toFloat(), it.height.toFloat()) }
            .drawBehind {
                val t = scene.time.floatValue
                if (drawer != null) drawer.draw(this, t) else drawFallbackBackground(t)
            }
    )
}

/**
 * Стеклянная панель: преломление, дисперсия, размытие, френель и блики.
 * [bevel] — ширина кромки, где свет гнётся; [refractionScale] усиливает общий параметр.
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 28.dp,
    bevel: Dp = 26.dp,
    refractionScale: Float = 1f,
    content: @Composable BoxScope.() -> Unit,
) {
    val scene = LocalGlassScene.current
    val drawer: GlassDrawer? = remember {
        if (sdkHasAgsl) AgslGlass() else null
    }
    var origin by remember { mutableStateOf(Offset.Zero) }

    Box(
        modifier
            .onGloballyPositioned { origin = it.positionInRoot() }
            .drawBehind {
                if (drawer != null) {
                    drawer.draw(
                        scope = this,
                        time = scene.time.floatValue,
                        screen = scene.screenSize,
                        origin = origin,
                        cornerRadius = cornerRadius.toPx(),
                        refraction = scene.refraction.floatValue.dp.toPx() * refractionScale,
                        dispersion = scene.dispersion.floatValue,
                        blur = scene.blur.floatValue.dp.toPx(),
                        bevel = bevel.toPx(),
                    )
                } else {
                    drawFallbackGlass(cornerRadius.toPx())
                }
            },
        content = content,
    )
}

// ---------- Фолбэк для Android 8–12 (без AGSL) ----------

private fun DrawScope.drawFallbackBackground(t: Float) {
    drawRect(Brush.verticalGradient(listOf(Color(0xFF0B1033), Color(0xFF2A0B3D))))
    val colors = listOf(Color(0xFF00E5FF), Color(0xFFFF4081), Color(0xFF7C4DFF), Color(0xFFFFC107))
    val r = size.minDimension * 0.6f
    colors.forEachIndexed { i, c ->
        val a = t * (0.25f + i * 0.07f) + i * 1.7f
        val center = Offset(
            size.width * (0.5f + 0.35f * sin(a)),
            size.height * (0.5f + 0.35f * cos(a * 1.3f)),
        )
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(c.copy(alpha = 0.55f), Color.Transparent),
                center = center,
                radius = r,
            ),
            radius = r,
            center = center,
        )
    }
}

private fun DrawScope.drawFallbackGlass(cornerRadius: Float) {
    val cr = CornerRadius(cornerRadius)
    drawRoundRect(
        brush = Brush.verticalGradient(
            listOf(Color.White.copy(alpha = 0.28f), Color.White.copy(alpha = 0.10f))
        ),
        cornerRadius = cr,
    )
    drawRoundRect(
        brush = Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = 0.70f),
                Color.White.copy(alpha = 0.05f),
                Color.White.copy(alpha = 0.30f),
            )
        ),
        cornerRadius = cr,
        style = Stroke(width = 1.dp.toPx()),
    )
}
